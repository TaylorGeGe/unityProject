unity使用UGUI自制调色面板板，像PS的调色面板，对不对

下面是两张截图:

![image text](https://github.com/coding2233/UnityColor/blob/master/screenshots/00.png)

![image text](https://github.com/coding2233/UnityColor/blob/master/screenshots/01.png)
